/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.assimp;

import org.jspecify.annotations.*;

import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;

/** Callback function: {@link #invoke aiFileWriteProc} */
public abstract class AIFileWriteProc extends Callback implements AIFileWriteProcI {

    /**
     * Creates a {@code AIFileWriteProc} instance from the specified function pointer.
     *
     * @return the new {@code AIFileWriteProc}
     */
    public static AIFileWriteProc create(long functionPointer) { return create(Callback.get(functionPointer), functionPointer); }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code functionPointer} is {@code NULL}. */
    public static @Nullable AIFileWriteProc createSafe(long functionPointer) { return functionPointer == NULL ? null : create(functionPointer); }

    /** Creates a {@code AIFileWriteProc} instance that delegates to the specified {@code AIFileWriteProcI} instance. */
    public static AIFileWriteProc create(AIFileWriteProcI instance) { return create(instance, instance.address()); }

    private static AIFileWriteProc create(AIFileWriteProcI instance, long functionPointer) {
        return instance instanceof AIFileWriteProc
            ? (AIFileWriteProc)instance
            : new AIFileWriteProc(functionPointer) {
                @Override public long invoke(long pFile, long pBuffer, long memB, long count) {
                    return instance.invoke(pFile, pBuffer, memB, count);
                }
            };
    }

    protected AIFileWriteProc() {
        super(DESCRIPTOR);
    }

    AIFileWriteProc(long functionPointer) {
        super(functionPointer);
    }

}